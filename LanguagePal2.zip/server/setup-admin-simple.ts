async function setupDefaultAdmin() {
  try {
    console.log('✅ Admin setup completed (simplified version)');
  } catch (error) {
    console.error('❌ Error in setup:', error);
  }
}

export { setupDefaultAdmin };