import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage, FormDescription } from "@/components/ui/form";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus, Edit, Trash2, Eye, EyeOff, Save, X, Upload, Image } from "lucide-react";
import { apiRequest, getQueryFn } from "@/lib/queryClient";
import { useNotifications } from "@/components/notification-system";
import { insertProjectSchema, insertServiceSchema, insertBlogPostSchema, insertSiteSettingsSchema } from "@shared/schema";
import type { InsertProject, Project, InsertService, Service, InsertBlogPost, BlogPost, InsertSiteSettings, SiteSettings } from "@shared/schema";

interface CMSPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

export function CMSPanel({ isOpen, onClose }: CMSPanelProps) {
  const [activeTab, setActiveTab] = useState("projects");
  const [editingProject, setEditingProject] = useState<Project | null>(null);
  const [editingService, setEditingService] = useState<Service | null>(null);
  const [editingBlogPost, setEditingBlogPost] = useState<BlogPost | null>(null);
  const [isProjectDialogOpen, setIsProjectDialogOpen] = useState(false);
  const [isServiceDialogOpen, setIsServiceDialogOpen] = useState(false);
  const [isBlogPostDialogOpen, setIsBlogPostDialogOpen] = useState(false);
  const [uploadingBlogImage, setUploadingBlogImage] = useState(false);
  
  const { addNotification } = useNotifications();
  const queryClient = useQueryClient();

  // Queries
  const { data: projects = [], isLoading: projectsLoading } = useQuery<Project[]>({
    queryKey: ["/api/admin/projects"],
    queryFn: getQueryFn({ on401: "returnNull" }),
  });

  const { data: services = [], isLoading: servicesLoading } = useQuery<Service[]>({
    queryKey: ["/api/admin/services"],
    queryFn: getQueryFn({ on401: "returnNull" }),
  });

  const { data: blogPosts = [], isLoading: blogPostsLoading } = useQuery<BlogPost[]>({
    queryKey: ["/api/admin/blog"],
    queryFn: getQueryFn({ on401: "returnNull" }),
  });

  const { data: siteSettings, isLoading: settingsLoading } = useQuery<SiteSettings>({
    queryKey: ["/api/site-settings"],
    queryFn: getQueryFn({ on401: "returnNull" }),
  });

  // Project form
  const projectForm = useForm<InsertProject>({
    resolver: zodResolver(insertProjectSchema),
    defaultValues: {
      title: "",
      description: "",
      imageUrl: "",
      technologies: [],
      projectUrl: "",
      isVisible: true,
      order: 0,
    },
  });

  // Service form
  const serviceForm = useForm<InsertService>({
    resolver: zodResolver(insertServiceSchema),
    defaultValues: {
      title: "",
      description: "",
      icon: "",
      features: [],
      isVisible: true,
      order: 0,
    },
  });

  // Blog post form
  const blogPostForm = useForm<InsertBlogPost>({
    resolver: zodResolver(insertBlogPostSchema),
    defaultValues: {
      title: "",
      slug: "",
      excerpt: "",
      content: "",
      imageUrl: "",
      tags: [],
      isPublished: false,
    },
  });

  // Site settings form
  const settingsForm = useForm<InsertSiteSettings>({
    resolver: zodResolver(insertSiteSettingsSchema),
    defaultValues: {
      phone: "",
      email: "",
      address: "",
      facebookUrl: "",
      facebookVisible: true,
      instagramUrl: "",
      instagramVisible: true,
      youtubeUrl: "",
      youtubeVisible: true,
      telegramUrl: "",
      telegramVisible: true,
      githubUrl: "",
      githubVisible: true,
      linkedinUrl: "",
      linkedinVisible: true,
      footerDescription: "",
      footerDescriptionUk: "",
      footerDescriptionRu: "",
      footerDescriptionEn: "",
      companyName: "",
      logoUrl: "",
    },
  });

  // Mutations
  const createProjectMutation = useMutation({
    mutationFn: (data: InsertProject) => apiRequest("POST", "/api/admin/projects", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/projects"] });
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      addNotification({ type: 'success', title: 'Проект создан', message: 'Новый проект успешно добавлен' });
      setIsProjectDialogOpen(false);
      projectForm.reset();
    },
  });

  const updateProjectMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: Partial<InsertProject> }) =>
      apiRequest("PATCH", `/api/admin/projects/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/projects"] });
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      addNotification({ type: 'success', title: 'Проект обновлен', message: 'Изменения сохранены' });
      setEditingProject(null);
      setIsProjectDialogOpen(false);
      projectForm.reset();
    },
  });

  const deleteProjectMutation = useMutation({
    mutationFn: (id: number) => apiRequest("DELETE", `/api/admin/projects/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/projects"] });
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      addNotification({ type: 'success', title: 'Проект удален', message: 'Проект успешно удален' });
    },
  });

  const createServiceMutation = useMutation({
    mutationFn: (data: InsertService) => apiRequest("POST", "/api/admin/services", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/services"] });
      queryClient.invalidateQueries({ queryKey: ["/api/services"] });
      addNotification({ type: 'success', title: 'Услуга создана', message: 'Новая услуга успешно добавлена' });
      setIsServiceDialogOpen(false);
      serviceForm.reset();
    },
  });

  const updateServiceMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: Partial<InsertService> }) =>
      apiRequest("PATCH", `/api/admin/services/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/services"] });
      queryClient.invalidateQueries({ queryKey: ["/api/services"] });
      addNotification({ type: 'success', title: 'Услуга обновлена', message: 'Изменения сохранены' });
      setEditingService(null);
      setIsServiceDialogOpen(false);
      serviceForm.reset();
    },
  });

  const deleteServiceMutation = useMutation({
    mutationFn: (id: number) => apiRequest("DELETE", `/api/admin/services/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/services"] });
      queryClient.invalidateQueries({ queryKey: ["/api/services"] });
      addNotification({ type: 'success', title: 'Услуга удалена', message: 'Услуга успешно удалена' });
    },
  });

  const createBlogPostMutation = useMutation({
    mutationFn: (data: InsertBlogPost) => apiRequest("POST", "/api/admin/blog", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/blog"] });
      queryClient.invalidateQueries({ queryKey: ["/api/blog"] });
      addNotification({ type: 'success', title: 'Статья создана', message: 'Новая статья успешно добавлена' });
      setIsBlogPostDialogOpen(false);
      blogPostForm.reset();
    },
  });

  const updateBlogPostMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: Partial<InsertBlogPost> }) =>
      apiRequest(`/api/admin/blog/${id}`, "PATCH", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/blog"] });
      queryClient.invalidateQueries({ queryKey: ["/api/blog"] });
      addNotification({ type: 'success', title: 'Статья обновлена', message: 'Изменения сохранены' });
      setEditingBlogPost(null);
      setIsBlogPostDialogOpen(false);
      blogPostForm.reset();
    },
  });

  const deleteBlogPostMutation = useMutation({
    mutationFn: (id: number) => apiRequest(`/api/admin/blog/${id}`, "DELETE"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/blog"] });
      queryClient.invalidateQueries({ queryKey: ["/api/blog"] });
      addNotification({ type: 'success', title: 'Статья удалена', message: 'Статья успешно удалена' });
    },
  });

  const updateSiteSettingsMutation = useMutation({
    mutationFn: (data: Partial<InsertSiteSettings>) => apiRequest("PUT", "/api/admin/site-settings", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/site-settings"] });
      addNotification({ type: 'success', title: 'Настройки сохранены', message: 'Настройки сайта успешно обновлены' });
    },
  });

  const handleEditProject = (project: Project) => {
    setEditingProject(project);
    projectForm.reset({
      title: project.title,
      description: project.description,
      imageUrl: project.imageUrl,
      technologies: project.technologies,
      projectUrl: project.projectUrl || "",
      isVisible: project.isVisible,
      order: project.order,
    });
    setIsProjectDialogOpen(true);
  };

  const handleEditService = (service: Service) => {
    setEditingService(service);
    serviceForm.reset({
      title: service.title,
      description: service.description,
      icon: service.icon,
      features: service.features,
      isVisible: service.isVisible,
      order: service.order,
    });
    setIsServiceDialogOpen(true);
  };

  const toggleProjectVisibility = (project: Project) => {
    updateProjectMutation.mutate({
      id: project.id,
      data: { isVisible: !project.isVisible }
    });
  };

  const toggleServiceVisibility = (service: Service) => {
    updateServiceMutation.mutate({
      id: service.id,
      data: { isVisible: !service.isVisible }
    });
  };

  const handleEditBlogPost = (blogPost: BlogPost) => {
    setEditingBlogPost(blogPost);
    blogPostForm.reset({
      title: blogPost.title,
      slug: blogPost.slug,
      excerpt: blogPost.excerpt,
      content: blogPost.content,
      imageUrl: blogPost.imageUrl,
      tags: blogPost.tags,
      isPublished: blogPost.isPublished,
    });
    setIsBlogPostDialogOpen(true);
  };

  const toggleBlogPostPublication = (blogPost: BlogPost) => {
    updateBlogPostMutation.mutate({
      id: blogPost.id,
      data: { isPublished: !blogPost.isPublished }
    });
  };

  const handleBlogImageUpload = async (file: File) => {
    if (!file) return;

    setUploadingBlogImage(true);
    try {
      const formData = new FormData();
      formData.append('image', file);

      const response = await fetch('/api/upload/blog-image', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        throw new Error('Ошибка загрузки изображения');
      }

      const { imageUrl } = await response.json();
      blogPostForm.setValue('imageUrl', imageUrl);
      addNotification({ 
        type: 'success', 
        title: 'Изображение загружено', 
        message: 'Изображение успешно загружено и добавлено к статье' 
      });
    } catch (error) {
      addNotification({ 
        type: 'error', 
        title: 'Ошибка загрузки', 
        message: 'Не удалось загрузить изображение. Попробуйте еще раз.' 
      });
    } finally {
      setUploadingBlogImage(false);
    }
  };

  // Load site settings into form when data is available
  useEffect(() => {
    if (siteSettings && !settingsForm.formState.isDirty) {
      settingsForm.reset({
        phone: siteSettings.phone || "",
        email: siteSettings.email || "",
        address: siteSettings.address || "",
        facebookUrl: siteSettings.facebookUrl || "",
        facebookVisible: siteSettings.facebookVisible ?? true,
        instagramUrl: siteSettings.instagramUrl || "",
        instagramVisible: siteSettings.instagramVisible ?? true,
        youtubeUrl: siteSettings.youtubeUrl || "",
        youtubeVisible: siteSettings.youtubeVisible ?? true,
        telegramUrl: siteSettings.telegramUrl || "",
        telegramVisible: siteSettings.telegramVisible ?? true,
        githubUrl: siteSettings.githubUrl || "",
        githubVisible: siteSettings.githubVisible ?? true,
        linkedinUrl: siteSettings.linkedinUrl || "",
        linkedinVisible: siteSettings.linkedinVisible ?? true,
        footerDescription: siteSettings.footerDescription || "",
        footerDescriptionUk: siteSettings.footerDescriptionUk || "",
        footerDescriptionRu: siteSettings.footerDescriptionRu || "",
        footerDescriptionEn: siteSettings.footerDescriptionEn || "",
        companyName: siteSettings.companyName || "",
        logoUrl: siteSettings.logoUrl || "",
        // Hero content fields
        heroTitle1Uk: siteSettings.heroTitle1Uk || "",
        heroTitle1Ru: siteSettings.heroTitle1Ru || "",
        heroTitle1En: siteSettings.heroTitle1En || "",
        heroTitle2Uk: siteSettings.heroTitle2Uk || "",
        heroTitle2Ru: siteSettings.heroTitle2Ru || "",
        heroTitle2En: siteSettings.heroTitle2En || "",
        heroTitle3Uk: siteSettings.heroTitle3Uk || "",
        heroTitle3Ru: siteSettings.heroTitle3Ru || "",
        heroTitle3En: siteSettings.heroTitle3En || "",
        heroDescriptionUk: siteSettings.heroDescriptionUk || "",
        heroDescriptionRu: siteSettings.heroDescriptionRu || "",
        heroDescriptionEn: siteSettings.heroDescriptionEn || "",
        // Header/Navigation settings
        showServicesMenu: siteSettings.showServicesMenu ?? true,
        showPortfolioMenu: siteSettings.showPortfolioMenu ?? true,
        showAboutMenu: siteSettings.showAboutMenu ?? true,
        showContactMenu: siteSettings.showContactMenu ?? true,
        showBlogMenu: siteSettings.showBlogMenu ?? true,
        showAdminMenu: siteSettings.showAdminMenu ?? true,
        // Menu labels translations
        servicesMenuUk: siteSettings.servicesMenuUk || "",
        servicesMenuRu: siteSettings.servicesMenuRu || "",
        servicesMenuEn: siteSettings.servicesMenuEn || "",
        portfolioMenuUk: siteSettings.portfolioMenuUk || "",
        portfolioMenuRu: siteSettings.portfolioMenuRu || "",
        portfolioMenuEn: siteSettings.portfolioMenuEn || "",
        aboutMenuUk: siteSettings.aboutMenuUk || "",
        aboutMenuRu: siteSettings.aboutMenuRu || "",
        aboutMenuEn: siteSettings.aboutMenuEn || "",
        contactMenuUk: siteSettings.contactMenuUk || "",
        contactMenuRu: siteSettings.contactMenuRu || "",
        contactMenuEn: siteSettings.contactMenuEn || "",
        blogMenuUk: siteSettings.blogMenuUk || "",
        blogMenuRu: siteSettings.blogMenuRu || "",
        blogMenuEn: siteSettings.blogMenuEn || "",
        adminMenuUk: siteSettings.adminMenuUk || "",
        adminMenuRu: siteSettings.adminMenuRu || "",
        adminMenuEn: siteSettings.adminMenuEn || "",
      });
    }
  }, [siteSettings]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm">
      <div className="fixed right-0 top-0 h-full w-full max-w-4xl bg-white shadow-2xl overflow-y-auto">
        <div className="sticky top-0 bg-white border-b p-6 flex items-center justify-between">
          <h1 className="text-2xl font-bold">CMS - Управление контентом</h1>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="w-5 h-5" />
          </Button>
        </div>

        <div className="p-6">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="projects">Наши работы</TabsTrigger>
              <TabsTrigger value="services">Услуги</TabsTrigger>
              <TabsTrigger value="blog">Блог</TabsTrigger>
              <TabsTrigger value="header">Шапка сайта</TabsTrigger>
              <TabsTrigger value="settings">Настройки сайта</TabsTrigger>
            </TabsList>

            {/* Projects Tab */}
            <TabsContent value="projects" className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-semibold">Управление разделом "Наши работы"</h2>
                <Dialog open={isProjectDialogOpen} onOpenChange={setIsProjectDialogOpen}>
                  <DialogTrigger asChild>
                    <Button onClick={() => { setEditingProject(null); projectForm.reset(); }}>
                      <Plus className="w-4 h-4 mr-2" />
                      Добавить проект
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle>
                        {editingProject ? "Редактировать проект" : "Новый проект"}
                      </DialogTitle>
                    </DialogHeader>
                    
                    <Form {...projectForm}>
                      <form onSubmit={projectForm.handleSubmit((data) => {
                        if (editingProject) {
                          updateProjectMutation.mutate({ id: editingProject.id, data });
                        } else {
                          createProjectMutation.mutate(data);
                        }
                      })} className="space-y-4">
                        <FormField
                          control={projectForm.control}
                          name="title"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Название</FormLabel>
                              <FormControl>
                                <Input {...field} placeholder="Название проекта" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={projectForm.control}
                          name="description"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Описание</FormLabel>
                              <FormControl>
                                <Textarea {...field} placeholder="Описание проекта" rows={3} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={projectForm.control}
                          name="imageUrl"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Изображение проекта</FormLabel>
                              <div className="space-y-3">
                                <div className="flex gap-2">
                                  <FormControl>
                                    <Input 
                                      {...field} 
                                      placeholder="https://example.com/image.jpg или загрузите файл ниже" 
                                      className="flex-1"
                                    />
                                  </FormControl>
                                </div>
                                <div className="border-2 border-dashed border-gray-300 hover:border-gray-400 rounded-lg p-6 text-center transition-colors">
                                  <div className="flex flex-col items-center gap-2">
                                    <Upload className="w-8 h-8 text-gray-400" />
                                    <div>
                                      <label className="cursor-pointer">
                                        <span className="text-sm font-medium text-blue-600 hover:text-blue-500">
                                          Нажмите для загрузки
                                        </span>
                                        <input
                                          type="file"
                                          accept="image/*"
                                          onChange={(e) => {
                                            const file = e.target.files?.[0];
                                            if (file) {
                                              const reader = new FileReader();
                                              reader.onload = (event) => {
                                                if (event.target?.result) {
                                                  field.onChange(event.target.result as string);
                                                }
                                              };
                                              reader.readAsDataURL(file);
                                            }
                                          }}
                                          className="hidden"
                                        />
                                      </label>
                                      <span className="text-sm text-gray-500"> или перетащите файл сюда</span>
                                    </div>
                                    <p className="text-xs text-gray-400">
                                      PNG, JPG, GIF до 10MB
                                    </p>
                                  </div>
                                </div>
                                {field.value && (
                                  <div className="mt-3 relative">
                                    <div className="relative inline-block">
                                      <img 
                                        src={field.value} 
                                        alt="Предпросмотр проекта" 
                                        className="max-w-full h-32 object-cover rounded-lg border shadow-sm"
                                      />
                                      <Button
                                        type="button"
                                        size="sm"
                                        variant="destructive"
                                        className="absolute -top-2 -right-2 h-6 w-6 rounded-full p-0"
                                        onClick={() => field.onChange("")}
                                      >
                                        <X className="h-3 w-3" />
                                      </Button>
                                    </div>
                                    <p className="text-xs text-gray-500 mt-1">
                                      <Image className="w-3 h-3 inline mr-1" />
                                      Изображение загружено
                                    </p>
                                  </div>
                                )}
                              </div>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={projectForm.control}
                          name="technologies"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Технологии</FormLabel>
                              <FormControl>
                                <Input 
                                  {...field} 
                                  value={field.value?.join(", ") || ""} 
                                  onChange={(e) => field.onChange(e.target.value.split(",").map(tech => tech.trim()).filter(Boolean))}
                                  placeholder="React, TypeScript, Node.js" 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={projectForm.control}
                          name="projectUrl"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>URL проекта</FormLabel>
                              <FormControl>
                                <Input {...field} value={field.value || ""} placeholder="https://project-url.com" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={projectForm.control}
                            name="order"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Порядок</FormLabel>
                                <FormControl>
                                  <Input 
                                    {...field} 
                                    type="number" 
                                    placeholder="0"
                                    onChange={(e) => field.onChange(Number(e.target.value))}
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={projectForm.control}
                            name="isVisible"
                            render={({ field }) => (
                              <FormItem className="flex items-center space-x-2 pt-8">
                                <FormControl>
                                  <Switch
                                    checked={field.value}
                                    onCheckedChange={field.onChange}
                                  />
                                </FormControl>
                                <FormLabel>Видимый</FormLabel>
                              </FormItem>
                            )}
                          />
                        </div>

                        <div className="flex justify-end gap-2">
                          <Button 
                            type="button" 
                            variant="outline" 
                            onClick={() => setIsProjectDialogOpen(false)}
                          >
                            Отмена
                          </Button>
                          <Button type="submit" disabled={createProjectMutation.isPending || updateProjectMutation.isPending}>
                            <Save className="w-4 h-4 mr-2" />
                            {editingProject ? "Сохранить" : "Создать"}
                          </Button>
                        </div>
                      </form>
                    </Form>
                  </DialogContent>
                </Dialog>
              </div>

              <div className="grid gap-4">
                {projectsLoading ? (
                  <div className="text-center py-8">Загрузка проектов...</div>
                ) : projects.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">Проектов пока нет</div>
                ) : (
                  projects
                    .sort((a, b) => a.order - b.order)
                    .map((project: Project) => (
                    <Card key={project.id}>
                      <CardHeader className="pb-2">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <CardTitle className="text-lg">{project.title}</CardTitle>
                            <Badge variant={project.isVisible ? "default" : "secondary"}>
                              {project.isVisible ? "Видимый" : "Скрытый"}
                            </Badge>
                          </div>
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => toggleProjectVisibility(project)}
                            >
                              {project.isVisible ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                            </Button>
                            <Button size="sm" variant="outline" onClick={() => handleEditProject(project)}>
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => deleteProjectMutation.mutate(project.id)}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          <p className="text-sm text-muted-foreground">{project.description}</p>
                          
                          <div className="flex gap-2 flex-wrap">
                            {project.technologies.map((tech, index) => (
                              <Badge key={index} variant="outline" className="text-xs">{tech}</Badge>
                            ))}
                          </div>
                          
                          <div className="flex items-center justify-between text-xs text-muted-foreground">
                            <span>Порядок: {project.order}</span>
                            {project.projectUrl && (
                              <a 
                                href={project.projectUrl} 
                                target="_blank" 
                                rel="noopener noreferrer"
                                className="text-blue-600 hover:underline"
                              >
                                Открыть проект
                              </a>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            </TabsContent>

            {/* Services Tab */}
            <TabsContent value="services" className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-semibold">Управление услугами</h2>
                <Dialog open={isServiceDialogOpen} onOpenChange={setIsServiceDialogOpen}>
                  <DialogTrigger asChild>
                    <Button onClick={() => { setEditingService(null); serviceForm.reset(); }}>
                      <Plus className="w-4 h-4 mr-2" />
                      Добавить услугу
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle>
                        {editingService ? "Редактировать услугу" : "Новая услуга"}
                      </DialogTitle>
                    </DialogHeader>
                    
                    <Form {...serviceForm}>
                      <form onSubmit={serviceForm.handleSubmit((data) => {
                        if (editingService) {
                          updateServiceMutation.mutate({ id: editingService.id, data });
                        } else {
                          createServiceMutation.mutate(data);
                        }
                      })} className="space-y-4">
                        <FormField
                          control={serviceForm.control}
                          name="title"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Название</FormLabel>
                              <FormControl>
                                <Input {...field} placeholder="Название услуги" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={serviceForm.control}
                          name="description"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Описание</FormLabel>
                              <FormControl>
                                <Textarea {...field} placeholder="Описание услуги" rows={3} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={serviceForm.control}
                          name="icon"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Иконка (Lucide)</FormLabel>
                              <FormControl>
                                <Input {...field} placeholder="Monitor" />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <div className="grid grid-cols-2 gap-4">
                          <FormField
                            control={serviceForm.control}
                            name="order"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Порядок</FormLabel>
                                <FormControl>
                                  <Input 
                                    {...field} 
                                    type="number" 
                                    placeholder="0"
                                    onChange={(e) => field.onChange(Number(e.target.value))}
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />

                          <FormField
                            control={serviceForm.control}
                            name="isVisible"
                            render={({ field }) => (
                              <FormItem className="flex items-center space-x-2 pt-8">
                                <FormControl>
                                  <Switch
                                    checked={field.value}
                                    onCheckedChange={field.onChange}
                                  />
                                </FormControl>
                                <FormLabel>Видимая</FormLabel>
                              </FormItem>
                            )}
                          />
                        </div>

                        <div className="flex justify-end gap-2">
                          <Button 
                            type="button" 
                            variant="outline" 
                            onClick={() => setIsServiceDialogOpen(false)}
                          >
                            Отмена
                          </Button>
                          <Button type="submit" disabled={createServiceMutation.isPending || updateServiceMutation.isPending}>
                            <Save className="w-4 h-4 mr-2" />
                            {editingService ? "Сохранить" : "Создать"}
                          </Button>
                        </div>
                      </form>
                    </Form>
                  </DialogContent>
                </Dialog>
              </div>

              <div className="grid gap-4">
                {servicesLoading ? (
                  <div className="text-center py-8">Загрузка услуг...</div>
                ) : services.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">Услуг пока нет</div>
                ) : (
                  services.map((service: Service) => (
                    <Card key={service.id}>
                      <CardHeader className="pb-2">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <CardTitle className="text-lg">{service.title}</CardTitle>
                            <Badge variant={service.isVisible ? "default" : "secondary"}>
                              {service.isVisible ? "Видимая" : "Скрытая"}
                            </Badge>
                          </div>
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => toggleServiceVisibility(service)}
                            >
                              {service.isVisible ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                            </Button>
                            <Button size="sm" variant="outline" onClick={() => handleEditService(service)}>
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => deleteServiceMutation.mutate(service.id)}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-muted-foreground mb-2">{service.description}</p>
                        <div className="flex gap-2 flex-wrap">
                          {service.features.map((feature, index) => (
                            <Badge key={index} variant="outline">{feature}</Badge>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            </TabsContent>

            {/* Blog Tab */}
            <TabsContent value="blog" className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-semibold">Управление блогом</h2>
                <Dialog open={isBlogPostDialogOpen} onOpenChange={setIsBlogPostDialogOpen}>
                  <DialogTrigger asChild>
                    <Button onClick={() => { setEditingBlogPost(null); blogPostForm.reset(); }}>
                      <Plus className="w-4 h-4 mr-2" />
                      Добавить статью
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle>
                        {editingBlogPost ? "Редактировать статью" : "Новая статья"}
                      </DialogTitle>
                    </DialogHeader>
                    <Form {...blogPostForm}>
                      <form onSubmit={blogPostForm.handleSubmit((data) => {
                        if (editingBlogPost) {
                          updateBlogPostMutation.mutate({ id: editingBlogPost.id, data });
                        } else {
                          createBlogPostMutation.mutate(data);
                        }
                      })}>
                        <div className="grid gap-4">
                          <div className="grid grid-cols-2 gap-4">
                            <FormField
                              control={blogPostForm.control}
                              name="title"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Заголовок</FormLabel>
                                  <FormControl>
                                    <Input placeholder="Введите заголовок статьи" {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            <FormField
                              control={blogPostForm.control}
                              name="slug"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>URL (slug)</FormLabel>
                                  <FormControl>
                                    <Input placeholder="url-friendly-название" {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                          <FormField
                            control={blogPostForm.control}
                            name="excerpt"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Краткое описание</FormLabel>
                                <FormControl>
                                  <Textarea placeholder="Краткое описание статьи" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={blogPostForm.control}
                            name="content"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Содержание</FormLabel>
                                <FormControl>
                                  <Textarea 
                                    placeholder="Полное содержание статьи" 
                                    className="min-h-40"
                                    {...field} 
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={blogPostForm.control}
                            name="imageUrl"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Изображение статьи</FormLabel>
                                <div className="space-y-4">
                                  <div className="flex gap-4">
                                    <FormControl>
                                      <Input 
                                        placeholder="https://example.com/image.jpg" 
                                        {...field} 
                                        value={field.value ?? ''} 
                                      />
                                    </FormControl>
                                    <div className="flex gap-2">
                                      <Button
                                        type="button"
                                        variant="outline"
                                        disabled={uploadingBlogImage}
                                        onClick={() => {
                                          const input = document.createElement('input');
                                          input.type = 'file';
                                          input.accept = 'image/*';
                                          input.onchange = (e) => {
                                            const file = (e.target as HTMLInputElement).files?.[0];
                                            if (file) handleBlogImageUpload(file);
                                          };
                                          input.click();
                                        }}
                                      >
                                        {uploadingBlogImage ? (
                                          <div className="animate-spin w-4 h-4 border-2 border-primary border-t-transparent rounded-full" />
                                        ) : (
                                          <Upload className="w-4 h-4" />
                                        )}
                                        {uploadingBlogImage ? "Загрузка..." : "Загрузить"}
                                      </Button>
                                    </div>
                                  </div>
                                  {field.value && (
                                    <div className="mt-2">
                                      <img 
                                        src={field.value} 
                                        alt="Превью изображения" 
                                        className="w-full max-w-xs h-auto rounded-lg border"
                                        onError={(e) => {
                                          (e.target as HTMLImageElement).style.display = 'none';
                                        }}
                                      />
                                    </div>
                                  )}
                                </div>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={blogPostForm.control}
                            name="tags"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Теги (через запятую)</FormLabel>
                                <FormControl>
                                  <Input 
                                    placeholder="веб-разработка, дизайн, технологии" 
                                    value={field.value?.join(", ") || ""}
                                    onChange={(e) => field.onChange(e.target.value.split(",").map(tag => tag.trim()).filter(Boolean))}
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={blogPostForm.control}
                            name="isPublished"
                            render={({ field }) => (
                              <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                                <div className="space-y-0.5">
                                  <FormLabel className="text-base">Опубликовать статью</FormLabel>
                                  <div className="text-sm text-muted-foreground">
                                    Статья будет видна на сайте
                                  </div>
                                </div>
                                <FormControl>
                                  <Switch
                                    checked={field.value}
                                    onCheckedChange={field.onChange}
                                  />
                                </FormControl>
                              </FormItem>
                            )}
                          />
                          <div className="flex justify-end gap-3">
                            <Button 
                              type="button" 
                              variant="outline" 
                              onClick={() => setIsBlogPostDialogOpen(false)}
                            >
                              Отмена
                            </Button>
                            <Button 
                              type="submit" 
                              disabled={createBlogPostMutation.isPending || updateBlogPostMutation.isPending}
                            >
                              <Save className="w-4 h-4 mr-2" />
                              {editingBlogPost ? "Сохранить" : "Создать"}
                            </Button>
                          </div>
                        </div>
                      </form>
                    </Form>
                  </DialogContent>
                </Dialog>
              </div>

              <div className="grid gap-4">
                {blogPostsLoading ? (
                  <div>Загрузка...</div>
                ) : (
                  blogPosts.map((blogPost: BlogPost) => (
                    <Card key={blogPost.id} className="hover:shadow-md transition-shadow">
                      <CardHeader>
                        <div className="flex justify-between items-start">
                          <div>
                            <CardTitle className="text-lg">{blogPost.title}</CardTitle>
                            <div className="flex gap-2 mt-2">
                              <Badge variant={blogPost.isPublished ? "default" : "secondary"}>
                                {blogPost.isPublished ? "Опубликована" : "Черновик"}
                              </Badge>
                              <Badge variant="outline">{blogPost.slug}</Badge>
                            </div>
                          </div>
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => toggleBlogPostPublication(blogPost)}
                            >
                              {blogPost.isPublished ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                            </Button>
                            <Button size="sm" variant="outline" onClick={() => handleEditBlogPost(blogPost)}>
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => deleteBlogPostMutation.mutate(blogPost.id)}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-muted-foreground mb-3">{blogPost.excerpt}</p>
                        {blogPost.tags && blogPost.tags.length > 0 && (
                          <div className="flex gap-2 flex-wrap">
                            {blogPost.tags.map((tag, index) => (
                              <Badge key={index} variant="outline">{tag}</Badge>
                            ))}
                          </div>
                        )}
                        <div className="text-xs text-muted-foreground mt-3">
                          Создана: {new Date(blogPost.createdAt).toLocaleDateString('ru-RU')}
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            </TabsContent>

            {/* Header Management Tab */}
            <TabsContent value="header" className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-semibold">Управление шапкой сайта</h2>
              </div>

              <Form {...settingsForm}>
                <form onSubmit={settingsForm.handleSubmit((data) => updateSiteSettingsMutation.mutate(data))} className="space-y-6">
                  
                  {/* Logo Management */}
                  <Card>
                    <CardHeader>
                      <CardTitle>Логотип</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <FormField
                        control={settingsForm.control}
                        name="logoUrl"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>URL логотипа</FormLabel>
                            <div className="space-y-4">
                              {/* Current logo preview */}
                              {field.value && (
                                <div className="flex items-center space-x-3 p-3 border rounded-lg bg-gray-50">
                                  <img 
                                    src={field.value} 
                                    alt="Current logo" 
                                    className="w-12 h-12 object-contain"
                                    onError={(e) => {
                                      (e.target as HTMLImageElement).style.display = 'none';
                                    }}
                                  />
                                  <div className="flex-1">
                                    <p className="text-sm font-medium">Текущий логотип</p>
                                    <p className="text-xs text-gray-500 truncate">{field.value}</p>
                                  </div>
                                  <Button
                                    type="button"
                                    variant="outline"
                                    size="sm"
                                    onClick={() => field.onChange("")}
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </Button>
                                </div>
                              )}
                              
                              <FormControl>
                                <Input 
                                  placeholder="https://example.com/logo.png или загрузите файл ниже" 
                                  {...field} 
                                  value={field.value || ""} 
                                />
                              </FormControl>
                              
                              {/* File Upload Section */}
                              <div className="border-2 border-dashed border-gray-300 hover:border-gray-400 rounded-lg p-6 text-center transition-colors">
                                <div className="flex flex-col items-center gap-2">
                                  <Upload className="w-8 h-8 text-gray-400" />
                                  <div>
                                    <label className="cursor-pointer">
                                      <span className="text-sm font-medium text-blue-600 hover:text-blue-500">
                                        Загрузить файл логотипа
                                      </span>
                                      <input
                                        type="file"
                                        accept="image/*"
                                        className="hidden"
                                        onChange={(e) => {
                                          const file = e.target.files?.[0];
                                          if (file) {
                                            // Проверяем размер файла (макс 5MB)
                                            if (file.size > 5 * 1024 * 1024) {
                                              addNotification({
                                                type: 'error',
                                                priority: 'medium',
                                                title: 'Ошибка загрузки',
                                                message: 'Размер файла не должен превышать 5MB',
                                              });
                                              return;
                                            }
                                            
                                            // Конвертируем в base64
                                            const reader = new FileReader();
                                            reader.onload = (event) => {
                                              const base64 = event.target?.result as string;
                                              field.onChange(base64);
                                              addNotification({
                                                type: 'success',
                                                priority: 'low',
                                                title: 'Логотип загружен',
                                                message: 'Файл успешно загружен и конвертирован',
                                              });
                                            };
                                            reader.readAsDataURL(file);
                                          }
                                        }}
                                      />
                                    </label>
                                    <p className="text-xs text-gray-500 mt-1">
                                      PNG, JPG, SVG до 5MB
                                    </p>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </CardContent>
                  </Card>

                  {/* Navigation Menu Settings */}
                  <Card>
                    <CardHeader>
                      <CardTitle>Настройки навигационного меню</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      
                      {/* Services Menu */}
                      <div className="space-y-4">
                        <h4 className="text-sm font-medium text-muted-foreground">Услуги</h4>
                        <div className="flex items-center space-x-4">
                          <FormField
                            control={settingsForm.control}
                            name="showServicesMenu"
                            render={({ field }) => (
                              <FormItem className="flex flex-row items-center space-x-2">
                                <FormControl>
                                  <Switch
                                    checked={field.value ?? true}
                                    onCheckedChange={field.onChange}
                                  />
                                </FormControl>
                                <FormLabel>Показывать в меню</FormLabel>
                              </FormItem>
                            )}
                          />
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <FormField
                            control={settingsForm.control}
                            name="servicesMenuUk"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Украинский</FormLabel>
                                <FormControl>
                                  <Input placeholder="Послуги" {...field} value={field.value || ""} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={settingsForm.control}
                            name="servicesMenuRu"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Русский</FormLabel>
                                <FormControl>
                                  <Input placeholder="Услуги" {...field} value={field.value || ""} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={settingsForm.control}
                            name="servicesMenuEn"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>English</FormLabel>
                                <FormControl>
                                  <Input placeholder="Services" {...field} value={field.value || ""} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                      </div>

                      {/* Portfolio Menu */}
                      <div className="space-y-4">
                        <h4 className="text-sm font-medium text-muted-foreground">Портфолио</h4>
                        <div className="flex items-center space-x-4">
                          <FormField
                            control={settingsForm.control}
                            name="showPortfolioMenu"
                            render={({ field }) => (
                              <FormItem className="flex flex-row items-center space-x-2">
                                <FormControl>
                                  <Switch
                                    checked={field.value ?? true}
                                    onCheckedChange={field.onChange}
                                  />
                                </FormControl>
                                <FormLabel>Показывать в меню</FormLabel>
                              </FormItem>
                            )}
                          />
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <FormField
                            control={settingsForm.control}
                            name="portfolioMenuUk"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Украинский</FormLabel>
                                <FormControl>
                                  <Input placeholder="Портфоліо" {...field} value={field.value || ""} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={settingsForm.control}
                            name="portfolioMenuRu"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Русский</FormLabel>
                                <FormControl>
                                  <Input placeholder="Портфолио" {...field} value={field.value || ""} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={settingsForm.control}
                            name="portfolioMenuEn"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>English</FormLabel>
                                <FormControl>
                                  <Input placeholder="Portfolio" {...field} value={field.value || ""} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                      </div>

                      {/* About Menu */}
                      <div className="space-y-4">
                        <h4 className="text-sm font-medium text-muted-foreground">О нас</h4>
                        <div className="flex items-center space-x-4">
                          <FormField
                            control={settingsForm.control}
                            name="showAboutMenu"
                            render={({ field }) => (
                              <FormItem className="flex flex-row items-center space-x-2">
                                <FormControl>
                                  <Switch
                                    checked={field.value ?? true}
                                    onCheckedChange={field.onChange}
                                  />
                                </FormControl>
                                <FormLabel>Показывать в меню</FormLabel>
                              </FormItem>
                            )}
                          />
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <FormField
                            control={settingsForm.control}
                            name="aboutMenuUk"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Украинский</FormLabel>
                                <FormControl>
                                  <Input placeholder="Про нас" {...field} value={field.value || ""} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={settingsForm.control}
                            name="aboutMenuRu"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Русский</FormLabel>
                                <FormControl>
                                  <Input placeholder="О нас" {...field} value={field.value || ""} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={settingsForm.control}
                            name="aboutMenuEn"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>English</FormLabel>
                                <FormControl>
                                  <Input placeholder="About" {...field} value={field.value || ""} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                      </div>

                      {/* Contact Menu */}
                      <div className="space-y-4">
                        <h4 className="text-sm font-medium text-muted-foreground">Контакты</h4>
                        <div className="flex items-center space-x-4">
                          <FormField
                            control={settingsForm.control}
                            name="showContactMenu"
                            render={({ field }) => (
                              <FormItem className="flex flex-row items-center space-x-2">
                                <FormControl>
                                  <Switch
                                    checked={field.value ?? true}
                                    onCheckedChange={field.onChange}
                                  />
                                </FormControl>
                                <FormLabel>Показывать в меню</FormLabel>
                              </FormItem>
                            )}
                          />
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <FormField
                            control={settingsForm.control}
                            name="contactMenuUk"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Украинский</FormLabel>
                                <FormControl>
                                  <Input placeholder="Контакти" {...field} value={field.value || ""} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={settingsForm.control}
                            name="contactMenuRu"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Русский</FormLabel>
                                <FormControl>
                                  <Input placeholder="Контакты" {...field} value={field.value || ""} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={settingsForm.control}
                            name="contactMenuEn"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>English</FormLabel>
                                <FormControl>
                                  <Input placeholder="Contact" {...field} value={field.value || ""} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                      </div>

                      {/* Blog Menu */}
                      <div className="space-y-4">
                        <h4 className="text-sm font-medium text-muted-foreground">Блог</h4>
                        <div className="flex items-center space-x-4">
                          <FormField
                            control={settingsForm.control}
                            name="showBlogMenu"
                            render={({ field }) => (
                              <FormItem className="flex flex-row items-center space-x-2">
                                <FormControl>
                                  <Switch
                                    checked={field.value ?? true}
                                    onCheckedChange={field.onChange}
                                  />
                                </FormControl>
                                <FormLabel>Показывать в меню</FormLabel>
                              </FormItem>
                            )}
                          />
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <FormField
                            control={settingsForm.control}
                            name="blogMenuUk"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Украинский</FormLabel>
                                <FormControl>
                                  <Input placeholder="Блог" {...field} value={field.value || ""} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={settingsForm.control}
                            name="blogMenuRu"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Русский</FormLabel>
                                <FormControl>
                                  <Input placeholder="Блог" {...field} value={field.value || ""} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={settingsForm.control}
                            name="blogMenuEn"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>English</FormLabel>
                                <FormControl>
                                  <Input placeholder="Blog" {...field} value={field.value || ""} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                      </div>

                      {/* Admin Menu */}
                      <div className="space-y-4">
                        <h4 className="text-sm font-medium text-muted-foreground">Админ панель</h4>
                        <div className="flex items-center space-x-4">
                          <FormField
                            control={settingsForm.control}
                            name="showAdminMenu"
                            render={({ field }) => (
                              <FormItem className="flex flex-row items-center space-x-2">
                                <FormControl>
                                  <Switch
                                    checked={field.value ?? true}
                                    onCheckedChange={field.onChange}
                                  />
                                </FormControl>
                                <FormLabel>Показывать в меню</FormLabel>
                              </FormItem>
                            )}
                          />
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <FormField
                            control={settingsForm.control}
                            name="adminMenuUk"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Украинский</FormLabel>
                                <FormControl>
                                  <Input placeholder="Адмін" {...field} value={field.value || ""} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={settingsForm.control}
                            name="adminMenuRu"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Русский</FormLabel>
                                <FormControl>
                                  <Input placeholder="Админ" {...field} value={field.value || ""} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={settingsForm.control}
                            name="adminMenuEn"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>English</FormLabel>
                                <FormControl>
                                  <Input placeholder="Admin" {...field} value={field.value || ""} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                      </div>

                    </CardContent>
                  </Card>

                  <Button 
                    type="submit" 
                    className="w-full"
                    disabled={updateSiteSettingsMutation.isPending || settingsLoading}
                  >
                    {updateSiteSettingsMutation.isPending ? (
                      <>
                        <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2" />
                        Сохранение...
                      </>
                    ) : (
                      <>
                        <Save className="w-4 h-4 mr-2" />
                        Сохранить настройки шапки
                      </>
                    )}
                  </Button>
                </form>
              </Form>
            </TabsContent>

            {/* Site Settings Tab */}
            <TabsContent value="settings" className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-semibold">Настройки сайта</h2>
              </div>

              <Form {...settingsForm}>
                <form onSubmit={settingsForm.handleSubmit((data) => updateSiteSettingsMutation.mutate(data))} className="space-y-6">
                  
                  {/* Contact Information */}
                  <Card>
                    <CardHeader>
                      <CardTitle>Контактная информация</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <FormField
                        control={settingsForm.control}
                        name="companyName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Название компании</FormLabel>
                            <FormControl>
                              <Input placeholder="Webservice Studio" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={settingsForm.control}
                        name="phone"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Телефон</FormLabel>
                            <FormControl>
                              <Input placeholder="+380959212203" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={settingsForm.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email</FormLabel>
                            <FormControl>
                              <Input placeholder="support@web-service.studio" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={settingsForm.control}
                        name="address"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Адрес</FormLabel>
                            <FormControl>
                              <Textarea 
                                placeholder="Україна, 52501, м.Синельникове, вул.Миру 36" 
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </CardContent>
                  </Card>

                  {/* Social Media Links */}
                  <Card>
                    <CardHeader>
                      <CardTitle>Социальные сети</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                        <FormField
                          control={settingsForm.control}
                          name="facebookUrl"
                          render={({ field }) => (
                            <FormItem className="lg:col-span-2">
                              <FormLabel>Facebook URL</FormLabel>
                              <FormControl>
                                <Input placeholder="https://facebook.com/your-page" {...field} value={field.value || ""} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={settingsForm.control}
                          name="facebookVisible"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                              <div className="space-y-0.5">
                                <FormLabel className="text-base">Показывать</FormLabel>
                                <FormDescription>
                                  Отображать иконку в футере
                                </FormDescription>
                              </div>
                              <FormControl>
                                <Switch
                                  checked={field.value ?? true}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />
                      </div>
                      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                        <FormField
                          control={settingsForm.control}
                          name="instagramUrl"
                          render={({ field }) => (
                            <FormItem className="lg:col-span-2">
                              <FormLabel>Instagram URL</FormLabel>
                              <FormControl>
                                <Input placeholder="https://instagram.com/your-profile" {...field} value={field.value || ""} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={settingsForm.control}
                          name="instagramVisible"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                              <div className="space-y-0.5">
                                <FormLabel className="text-base">Показывать</FormLabel>
                                <FormDescription>
                                  Отображать иконку в футере
                                </FormDescription>
                              </div>
                              <FormControl>
                                <Switch
                                  checked={field.value ?? true}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />
                      </div>
                      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                        <FormField
                          control={settingsForm.control}
                          name="youtubeUrl"
                          render={({ field }) => (
                            <FormItem className="lg:col-span-2">
                              <FormLabel>YouTube URL</FormLabel>
                              <FormControl>
                                <Input placeholder="https://youtube.com/@your-channel" {...field} value={field.value || ""} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={settingsForm.control}
                          name="youtubeVisible"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                              <div className="space-y-0.5">
                                <FormLabel className="text-base">Показывать</FormLabel>
                                <FormDescription>
                                  Отображать иконку в футере
                                </FormDescription>
                              </div>
                              <FormControl>
                                <Switch
                                  checked={field.value ?? true}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />
                      </div>
                      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                        <FormField
                          control={settingsForm.control}
                          name="telegramUrl"
                          render={({ field }) => (
                            <FormItem className="lg:col-span-2">
                              <FormLabel>Telegram URL</FormLabel>
                              <FormControl>
                                <Input placeholder="https://t.me/your-channel" {...field} value={field.value || ""} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={settingsForm.control}
                          name="telegramVisible"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                              <div className="space-y-0.5">
                                <FormLabel className="text-base">Показывать</FormLabel>
                                <FormDescription>
                                  Отображать иконку в футере
                                </FormDescription>
                              </div>
                              <FormControl>
                                <Switch
                                  checked={field.value ?? true}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />
                      </div>
                      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                        <FormField
                          control={settingsForm.control}
                          name="githubUrl"
                          render={({ field }) => (
                            <FormItem className="lg:col-span-2">
                              <FormLabel>GitHub URL</FormLabel>
                              <FormControl>
                                <Input placeholder="https://github.com/your-profile" {...field} value={field.value || ""} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={settingsForm.control}
                          name="githubVisible"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                              <div className="space-y-0.5">
                                <FormLabel className="text-base">Показывать</FormLabel>
                                <FormDescription>
                                  Отображать иконку в футере
                                </FormDescription>
                              </div>
                              <FormControl>
                                <Switch
                                  checked={field.value ?? true}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />
                      </div>
                      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                        <FormField
                          control={settingsForm.control}
                          name="linkedinUrl"
                          render={({ field }) => (
                            <FormItem className="lg:col-span-2">
                              <FormLabel>LinkedIn URL</FormLabel>
                              <FormControl>
                                <Input placeholder="https://linkedin.com/in/your-profile" {...field} value={field.value || ""} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={settingsForm.control}
                          name="linkedinVisible"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                              <div className="space-y-0.5">
                                <FormLabel className="text-base">Показывать</FormLabel>
                                <FormDescription>
                                  Отображать иконку в футере
                                </FormDescription>
                              </div>
                              <FormControl>
                                <Switch
                                  checked={field.value ?? true}
                                  onCheckedChange={field.onChange}
                                />
                              </FormControl>
                            </FormItem>
                          )}
                        />
                      </div>
                    </CardContent>
                  </Card>

                  {/* Company Settings */}
                  <Card>
                    <CardHeader>
                      <CardTitle>Настройки компании</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <FormField
                        control={settingsForm.control}
                        name="companyName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Название компании</FormLabel>
                            <FormControl>
                              <Input placeholder="Webservice Studio" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={settingsForm.control}
                        name="logoUrl"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Логотип</FormLabel>
                            <div className="space-y-4">
                              {/* Current logo preview */}
                              {field.value && (
                                <div className="flex items-center space-x-3 p-3 border rounded-lg bg-gray-50">
                                  <img 
                                    src={field.value} 
                                    alt="Current logo" 
                                    className="w-12 h-12 object-contain"
                                    onError={(e) => {
                                      (e.target as HTMLImageElement).style.display = 'none';
                                    }}
                                  />
                                  <div className="flex-1">
                                    <p className="text-sm font-medium">Текущий логотип</p>
                                    <p className="text-xs text-gray-500 truncate">{field.value}</p>
                                  </div>
                                  <Button
                                    type="button"
                                    variant="outline"
                                    size="sm"
                                    onClick={() => field.onChange("")}
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </Button>
                                </div>
                              )}
                              
                              {/* File upload */}
                              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6">
                                <div className="text-center">
                                  <Upload className="mx-auto h-12 w-12 text-gray-400" />
                                  <div className="mt-4">
                                    <label className="cursor-pointer">
                                      <span className="mt-2 block text-sm font-medium text-gray-900">
                                        Загрузить новый логотип
                                      </span>
                                      <input
                                        type="file"
                                        className="sr-only"
                                        accept="image/*"
                                        onChange={async (e) => {
                                          const file = e.target.files?.[0];
                                          if (file) {
                                            try {
                                              const formData = new FormData();
                                              formData.append('file', file);
                                              
                                              const response = await fetch('/api/upload', {
                                                method: 'POST',
                                                body: formData,
                                              });
                                              
                                              if (response.ok) {
                                                const data = await response.json();
                                                field.onChange(data.url);
                                              } else {
                                                console.error('Upload failed');
                                              }
                                            } catch (error) {
                                              console.error('Upload error:', error);
                                            }
                                          }
                                        }}
                                      />
                                    </label>
                                    <p className="mt-1 text-xs text-gray-500">
                                      PNG, JPG, SVG до 5MB
                                    </p>
                                  </div>
                                </div>
                              </div>
                              
                              {/* Manual URL input */}
                              <div>
                                <FormLabel className="text-sm font-medium">Или введите URL</FormLabel>
                                <FormControl>
                                  <Input 
                                    placeholder="https://example.com/logo.png" 
                                    {...field} 
                                    value={field.value || ""} 
                                  />
                                </FormControl>
                              </div>
                            </div>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <div className="space-y-4">
                        <h3 className="text-lg font-semibold">Описание компании</h3>
                        <FormField
                          control={settingsForm.control}
                          name="footerDescription"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Описание (основное)</FormLabel>
                              <FormControl>
                                <Textarea 
                                  placeholder="Професійна веб-розробка з використанням сучасних технологій" 
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={settingsForm.control}
                          name="footerDescriptionUk"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Описание (українська)</FormLabel>
                              <FormControl>
                                <Textarea 
                                  placeholder="Професійна веб-розробка з використанням сучасних технологій" 
                                  {...field} 
                                  value={field.value || ""}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={settingsForm.control}
                          name="footerDescriptionRu"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Описание (русский)</FormLabel>
                              <FormControl>
                                <Textarea 
                                  placeholder="Профессиональная веб-разработка с использованием современных технологий" 
                                  {...field} 
                                  value={field.value || ""}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={settingsForm.control}
                          name="footerDescriptionEn"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Описание (English)</FormLabel>
                              <FormControl>
                                <Textarea 
                                  placeholder="Professional web development using modern technologies" 
                                  {...field} 
                                  value={field.value || ""}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    </CardContent>
                  </Card>

                  <Button 
                    type="submit" 
                    className="w-full"
                    disabled={updateSiteSettingsMutation.isPending || settingsLoading}
                  >
                    {updateSiteSettingsMutation.isPending ? (
                      <>
                        <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2" />
                        Сохранение...
                      </>
                    ) : (
                      <>
                        <Save className="w-4 h-4 mr-2" />
                        Сохранить настройки
                      </>
                    )}
                  </Button>
                </form>
              </Form>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}